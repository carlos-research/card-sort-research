# TODO
- Customize onboarding
- Reorder groups
- Improve responsive
- Better horizontal scroll
- Allow vertical creation of groups
